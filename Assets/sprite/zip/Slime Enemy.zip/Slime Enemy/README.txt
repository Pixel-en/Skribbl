Hello! I'm War, thank you very much for purchasing my asset pack!

I would love to see the project that you'll use my animations on! 
You can send them to my twitter, or instagram, @wars_vault.

#################################################################

Credit is not necessary, but appreciated. If you wish to credit me, please do so as: Jovanny "War" Bert�

#################################################################

All animations come in all three colors, those beign, green, blue and red.

#################################################################

Animation Resolution: 96x32
Idle (7 Frames)
Jump
	Start-up (9 Frames)
	Up (1 Frame)
	Jump to Fall (5 Frames)
	Down (1 Frame)
	Land (6 Frames)
Hurt (11 Frames)
Death (14 Frames)

